@echo off
chcp 936 >nul
setlocal
set "PACK=%~dp0"
pushd "%PACK%.."
set "GAME=%CD%"
popd

if exist "%GAME%\mashimaro.orig.exe" (
    copy /y "%GAME%\mashimaro.orig.exe" "%GAME%\mashimaro.exe" >nul
    del "%GAME%\mashimaro.orig.exe"
    echo [���] �������ѻ�ԭ
)
if exist "%GAME%\script.noa.bak" (
    copy /y "%GAME%\script.noa.bak" "%GAME%\script.noa" >nul
    echo [���] script.noa �ѻ�ԭ
)
pause
